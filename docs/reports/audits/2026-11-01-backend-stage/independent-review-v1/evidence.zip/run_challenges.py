import hashlib,json,os,pathlib,subprocess,sys
OUT=pathlib.Path(__file__).resolve().parent
LABEL=sys.argv[1]
assert LABEL.replace('-','').isalnum()
root=OUT/LABEL
root.mkdir(exist_ok=False)
script=OUT/'test_independent_challenges.py'
(root/script.name).write_bytes(script.read_bytes())
cmd=['/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/.venv-deployment/bin/python', '-B','-m','pytest','-p','no:cacheprovider','-c','/dev/null','--confcutdir='+str(OUT),str(script),'-q','--junitxml='+str(root/'junit.xml'),'--basetemp='+str(root/'fixtures')]
cmd += sys.argv[2:]
result=subprocess.run(cmd,cwd=OUT,capture_output=True,text=True,timeout=180)
(root/'stdout.txt').write_text(result.stdout)
(root/'stderr.txt').write_text(result.stderr)
receipt={'command':cmd,'cwd':str(OUT),'uid':os.geteuid(),'returncode':result.returncode,'harness_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(pathlib.Path('/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/backend-stage-worktree-20261101/integrations/hermes/deployment/stage_audit_backend.py').read_bytes()).hexdigest()}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print(result.stdout);print(result.stderr)
raise SystemExit(result.returncode)
