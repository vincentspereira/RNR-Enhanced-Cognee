import hashlib,json,os,pathlib,stat,subprocess,zipfile,zlib
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/backend-stage-worktree-20261101')
ARCHIVE=OUT.with_suffix('.zip')
RECEIPT=OUT.with_name(OUT.name+'-archive-receipt.json')
def sha(data): return hashlib.sha256(data).hexdigest()
# Snapshot only relevant public source/config dependencies, never runtime bytes.
payload=json.loads((ROOT/'integrations/hermes/deployment/audit_backend_payload.json').read_bytes())
for relative in [*[row['path'] for row in payload['files']], 'pytest.ini']:
    target=OUT/'dependency-snapshots'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((ROOT/relative).read_bytes())
manifest=json.loads((OUT/'reviewed-manifest.json').read_bytes())
for row in manifest: assert sha((ROOT/row['path']).read_bytes())==row['sha256']
original=json.loads((OUT/'pre-state.json').read_bytes())
for field,cmd in [('head',['git','rev-parse','HEAD']),('branch',['git','branch','--show-current'])]:
    assert subprocess.check_output(cmd,cwd=ROOT,text=True).strip()==original[field]
for field,cmd in [('status',['git','status','--porcelain=v1','--untracked-files=all']),('tracked_diff',['git','diff','--binary']),('index_diff',['git','diff','--cached','--binary'])]:
    assert subprocess.check_output(cmd,cwd=ROOT,text=True)==original[field]
assert not os.path.lexists('/opt/enhanced-cognee-memory/candidates/audit-c14f595c-20261101')
assert not os.path.lexists('/opt/enhanced-cognee-memory/staging/audit-c14f595c-20261101')
fixtures=[]
for attempt in ['independent-01','independent-02']:
    base=OUT/attempt/'fixtures'
    for directory,dirs,files in os.walk(base,followlinks=False):
        for name in dirs+files:
            p=pathlib.Path(directory)/name
            s=p.lstat()
            row={'path':str(p.relative_to(OUT)),'mode':oct(stat.S_IMODE(s.st_mode))}
            if stat.S_ISLNK(s.st_mode): row.update(kind='link',target=os.readlink(p))
            elif stat.S_ISREG(s.st_mode): row.update(kind='file',sha256=sha(p.read_bytes()),size=s.st_size)
            elif stat.S_ISDIR(s.st_mode): row['kind']='directory'
            elif stat.S_ISFIFO(s.st_mode): row['kind']='fifo'
            elif stat.S_ISSOCK(s.st_mode): row['kind']='unix-socket-path'
            else: row['kind']='other'
            fixtures.append(row)
(OUT/'fixture-topology.json').write_text(json.dumps(fixtures,indent=2)+'\n')
conclusion={
 'passed':True,'security_concerns':[],'logic_errors':[],'suggestions':[],
 'summary':'Accepted exact seven-file stage-only source/owner-command candidate under documented exclusive-owner assumptions; no blocking security or correctness defect reproduced. No privileged bootstrap, protected staging or promotion occurred.',
 'reviewed_manifest':{'root':str(ROOT),'baseline':'c14f595ccd53f432b455b16f116765d9aa6c9a14','branch':original['branch'],'manifest_path':'docs/reports/audits/2026-11-01-backend-stage/review-manifest-v1.json','manifest_sha256':sha((ROOT/'docs/reports/audits/2026-11-01-backend-stage/review-manifest-v1.json').read_bytes()),'files':manifest},
 'tests_run':{'existing_offline':{'passed':58,'failures':0,'errors':0,'skips':0,'observed_warnings':0,'returncode':0},'independent_challenges':{'distinct_passed':60,'current_failures':0,'current_errors':0,'skips':0,'observed_warnings':0,'initial_run':{'passed':47,'reviewer_fixture_failures':2,'returncode':1},'corrected_replay_and_new_trust_cases':{'passed':13,'corrected_cases':2,'new_cases':11,'returncode':0},'original_failures_and_same_id_mappings_preserved':True,'coverage':['strict malformed/duplicate/trailing JSON with genuine controls','real Unix socket/FIFO paths and bad type/group/mode/ancestor metadata','exclusive new clone, independent complete inventory digest, old metadata/entrypoints retained','injected initial-marker/clone-read/clone-write/overlay-write/pending-write/final-rename/final-read faults, no false COMPLETE, preservation and refusal to reuse','root-execution flags, helper/executor lexical aliases, hardlinks and writable lexical parents using synthetic privilege metadata','exact module bytecode exclusion boundaries','both Bash blocks syntax checked; ten bootstrap hashes matched; extracted unprivileged reader rejects modified/final-symlink/missing inputs without stdout; invented stdin-install transport readback']},'distinct_total':118,'read_only_fixed_runtime_inspection':{'uid':1000,'returncode':0,'entries':7235,'inventory_sha256':'55897401aad689f945b96d0e9e56b17ee2165eb9567d2cce84347f0ac32b2926'},'payload_sources':{'bound_to_baseline':8,'modified':0},'preservation':{'seven_candidate_hashes_unchanged':True,'tracked_files_unchanged':True,'index_unchanged':True,'protected_destination_and_bundle_absent':True},'limitations':['Synthetic root stat/trust fixtures do not establish real privilege isolation or full cloned-runtime boot.','Root bootstrap and host stage operation were not executed; services/models/APIs/credentials/profiles untouched.','Activation, ledger provisioning/cutover accounting, relocation and backup recovery remain separate owner-gated phases.']},
 'evidence_paths':{'directory':str(OUT),'archive':str(ARCHIVE),'archive_receipt':str(RECEIPT),'reconciliation':str(OUT/'case-reconciliation.json'),'static_preservation':str(OUT/'static-and-preservation.json')}
}
(OUT/'review-conclusions.json').write_text(json.dumps(conclusion,indent=2)+'\n')
# Exclude generated trees with special files. Their complete metadata is retained
# above, and exact harness versions recreate them. No aliases to external files.
members=[]
for directory,dirs,files in os.walk(OUT,followlinks=False):
    dirs[:]=[name for name in dirs if name not in {'fixtures','__pycache__'}]
    for name in files:
        p=pathlib.Path(directory)/name
        assert p.is_file() and not p.is_symlink(),str(p)
        data=p.read_bytes()
        members.append({'path':str(p.relative_to(OUT)),'bytes':len(data),'sha256':sha(data),'crc32':format(zlib.crc32(data)&0xffffffff,'08x')})
members.sort(key=lambda row:row['path'])
index=OUT/'archive-members.json'
index.write_text(json.dumps({'excludes':'generated fixture trees; see fixture-topology.json and exact harness snapshots','index_self_hash_excluded':True,'members':members},indent=2)+'\n')
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for row in members:
        z.write(OUT/row['path'],row['path'])
    z.write(index,'archive-members.json')
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(members)+1 and len(set(z.namelist()))==len(z.namelist())
    assert set(z.namelist())=={row['path'] for row in members}|{'archive-members.json'}
    for row in members:
        data=z.read(row['path'])
        assert sha(data)==row['sha256']
        assert format(z.getinfo(row['path']).CRC,'08x')==row['crc32']
        assert len(data)==row['bytes']
    count=len(z.namelist())
data=ARCHIVE.read_bytes()
receipt={'archive':str(ARCHIVE),'bytes':len(data),'sha256':sha(data),'crc32':format(zlib.crc32(data)&0xffffffff,'08x'),'members':count,'zip_testzip':None,'all_member_sha256_and_crc32_verified':True,'duplicate_or_unindexed_members':False,'member_index_sha256':sha(index.read_bytes())}
RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n')
conclusion['evidence_paths']['archive_sha256']=receipt['sha256']
conclusion['evidence_paths']['archive_crc32']=receipt['crc32']
conclusion['evidence_paths']['archive_members']=receipt['members']
# Final verdict is adjacent to, not inside, the checksum-bound archive to avoid
# an impossible self-referential archive hash. Archived conclusions match scope.
final=OUT.with_name(OUT.name+'-verdict.json')
final.write_text(json.dumps(conclusion,indent=2)+'\n')
print(json.dumps({'verdict_path':str(final),'archive_receipt':receipt,'passed':conclusion['passed']},indent=2))
