"""Independent no-launch challenges; real scratch trees, synthetic root metadata.
No imports from candidate tests. Only helper is imported as stdlib-only data code.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
from types import SimpleNamespace

import pytest

REPO = Path('/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/backend-stage-worktree-20261101')
SOURCE = REPO / 'integrations/hermes/deployment/stage_audit_backend.py'
MANIFEST = SOURCE.with_name('audit_backend_payload.json')
COMMANDS = REPO / 'docs/reports/audits/2026-11-01-backend-stage/STAGE-COMMANDS.md'


def sha(data):
    return hashlib.sha256(data).hexdigest()


@pytest.fixture
def helper():
    spec = importlib.util.spec_from_file_location('fresh_independent_helper', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def env(helper, tmp_path, monkeypatch):
    """Ownership is synthetic, all within-boundary modes/inodes/IO are real."""
    root = tmp_path / 'review-root'
    old = root / 'candidates/old'
    dest = root / 'candidates/new'
    bundle = root / 'inputs'
    runtime = old / 'runtime'
    site = runtime / helper.SITE
    binary = root / 'os-bin/python3'
    for directory in [site / 'src/security', runtime / 'bin', bundle / 'src/security', binary.parent]:
        directory.mkdir(parents=True)
    binary.write_bytes(b'NEVER EXECUTE fixture OS binary')
    (runtime / 'bin/python').write_bytes(b'NEVER EXECUTE fixture runtime binary')
    (runtime / 'pyvenv.cfg').write_bytes(helper.PYVENV)
    (runtime / 'lib64').symlink_to('lib')
    (runtime / 'bin/entrypoint').write_bytes(b'#!/old/runtime/bin/python\n')
    meta = site / 'old.dist-info'
    meta.mkdir()
    (meta / 'RECORD').write_bytes(b'old metadata retained\n')
    bindings = {}
    for index, name in enumerate(helper.BINDINGS):
        previous = None if helper.BINDINGS[name][0] is None else ('OLD = %d\n' % index).encode()
        desired = ('NEW = %d\n' % index).encode()
        if previous is not None:
            (site / name).write_bytes(previous)
        (bundle / name).write_bytes(desired)
        bindings[name] = (None if previous is None else sha(previous), sha(desired))
    manifest = {'schema': 1, 'source_commit': helper.COMMIT, 'files': [
        {'path': name, 'old_sha256': oldhash, 'new_sha256': newhash}
        for name, (oldhash, newhash) in bindings.items()]}
    (bundle / 'audit_backend_payload.json').write_text(json.dumps(manifest))
    script = bundle / 'stage_audit_backend.py'
    script.write_bytes(SOURCE.read_bytes())
    for path in [tmp_path, *tmp_path.rglob('*')]:
        if path.is_symlink():
            continue
        path.chmod(0o755 if path.is_dir() else 0o644)
    binary.chmod(0o755)
    (runtime / 'bin/python').chmod(0o755)
    true_lstat = os.lstat
    def rootstat(path):
        path = Path(path)
        s = true_lstat(path)
        mode = s.st_mode if path.is_relative_to(tmp_path) else stat.S_IFDIR | 0o755
        return SimpleNamespace(st_uid=0, st_gid=0, st_mode=mode,
            st_nlink=s.st_nlink, st_dev=s.st_dev, st_ino=s.st_ino)
    for name, value in {'BASE': old, 'DEST': dest, 'BUNDLE': bundle,
                        'EXTERNAL_PYTHON': binary, 'EXECUTOR': binary,
                        'BINDINGS': bindings, '_lstat': rootstat, '__file__': str(script)}.items():
        monkeypatch.setattr(helper, name, value)
    # Do not monkeypatch global os.geteuid: only helper sees synthetic privileges.
    class OSFacade:
        def __getattr__(self, name):
            return getattr(os, name)
        @staticmethod
        def geteuid():
            return 0
    monkeypatch.setattr(helper, 'os', OSFacade())
    monkeypatch.setattr(helper, 'sys', SimpleNamespace(executable=str(binary),
        flags=SimpleNamespace(isolated=1, no_site=1, dont_write_bytecode=1)))
    return SimpleNamespace(root=root, old=old, dest=dest, bundle=bundle,
        runtime=runtime, site=site, binary=binary, script=script, rootstat=rootstat)


def positive_preflight(h, e):
    h.execution_trust()
    inventory = h.inspect_runtime()
    assert len(h.preflight_payload()) == 8
    assert not os.path.lexists(e.dest)
    return inventory


def test_complete_clone_independent_control(helper, env, monkeypatch):
    before = positive_preflight(helper, env)
    for name in ['model-cache', 'credential-cycle', 'operator-sensitive', 'artifacts']:
        private = env.old / name
        private.mkdir(mode=0o700)
        (private / 'do-not-read').write_text('synthetic private sibling')
    original_open = helper.os.open
    reads = []
    def guarded_open(path, flags, *args, **kwargs):
        p = Path(path)
        assert any(p.is_relative_to(boundary) for boundary in [env.runtime, env.dest, env.bundle])
        reads.append(str(p))
        return original_open(path, flags, *args, **kwargs)
    monkeypatch.setattr(helper.os, 'open', guarded_open)
    def forbidden(*a, **k):
        raise AssertionError('launch or network attempted')
    monkeypatch.setattr(subprocess, 'Popen', forbidden)
    monkeypatch.setattr(socket, 'socket', forbidden)
    monkeypatch.setattr(helper.os, 'system', forbidden)
    result = helper.stage_candidate()
    assert result['complete'] is True
    assert result['activated'] is False and result['ledger_created'] is False
    assert result['services_restarted'] is False and result['credentials_issued'] == 0
    assert result['wheel_metadata_rebuilt'] is False
    assert helper.inspect_runtime() == before
    assert result['original_runtime_inventory'] == sha(json.dumps(before, sort_keys=True).encode())
    assert result['helper_sha256'] == sha(SOURCE.read_bytes())
    assert json.loads((env.dest / 'COMPLETE.json').read_bytes()) == result
    actual = {}
    newruntime = env.dest / 'runtime'
    for path in [newruntime, *newruntime.rglob('*')]:
        rel = str(path.relative_to(newruntime))
        s = path.lstat()
        if path.is_symlink():
            actual[rel] = {'kind': 'link', 'target': os.readlink(path)}
        elif path.is_dir():
            actual[rel] = {'kind': 'dir', 'mode': stat.S_IMODE(s.st_mode)}
        else:
            assert s.st_nlink == 1
            actual[rel] = {'kind': 'file', 'mode': stat.S_IMODE(s.st_mode), 'sha256': sha(path.read_bytes())}
    assert result['runtime_inventory'] == sha(json.dumps(actual, sort_keys=True).encode())
    assert result['runtime_entries'] == len(actual)
    assert (newruntime / helper.SITE / 'old.dist-info/RECORD').read_bytes() == b'old metadata retained\n'
    assert (newruntime / 'bin/entrypoint').read_bytes() == b'#!/old/runtime/bin/python\n'
    assert reads


@pytest.mark.parametrize('change', ['null-files', 'dict-files', 'null-row', 'reorder',
    'bool-oldhash', 'float-newhash', 'duplicate-identical-top', 'duplicate-identical-row',
    'trailing-object', 'trailing-garbage', 'infinity', 'invalid-utf8', 'unknown-row-key'])
def test_new_manifest_challenges(helper, change):
    good = MANIFEST.read_bytes()
    assert len(helper.load_manifest(good)['files']) == 8
    obj = json.loads(good)
    if change == 'null-files': obj['files'] = None
    elif change == 'dict-files': obj['files'] = {}
    elif change == 'null-row': obj['files'][0] = None
    elif change == 'reorder': obj['files'].reverse()
    elif change == 'bool-oldhash': obj['files'][2]['old_sha256'] = False
    elif change == 'float-newhash': obj['files'][0]['new_sha256'] = 1.0
    elif change == 'unknown-row-key': obj['files'][0]['owner'] = 'root'
    data = json.dumps(obj).encode()
    if change == 'duplicate-identical-top': data = data.replace(b'"schema": 1', b'"schema": 1, "schema": 1')
    elif change == 'duplicate-identical-row': data = data.replace(b'"path": "src/ingestion.py"', b'"path": "src/ingestion.py", "path": "src/ingestion.py"')
    elif change == 'trailing-object': data += b'{}'
    elif change == 'trailing-garbage': data += b' ignored'
    elif change == 'infinity': data = data.replace(b'"schema": 1', b'"schema": Infinity')
    elif change == 'invalid-utf8': data += b'\xff'
    with pytest.raises(helper.Rejected): helper.load_manifest(data)


@pytest.mark.parametrize('change', ['socket', 'fifo', 'directory-instead-of-binary',
    'file-instead-of-source-parent', 'runtime-ancestor-alias', 'candidate-parent-writable',
    'bundle-fifo', 'helper-gid', 'target-gid', 'sticky-dir', 'setgid-file',
    'uppercase-pth', 'lib64-nested-link', 'private-artifacts', 'bad-json-manifest'])
def test_specialfile_metadata_challenges(helper, env, monkeypatch, change):
    positive_preflight(helper, env)
    if change == 'socket':
        sock = socket.socket(socket.AF_UNIX)
        sock.bind(str(env.runtime / 'surprise.sock'))
        sock.close()
    elif change == 'fifo': os.mkfifo(env.runtime / 'surprise.pipe')
    elif change == 'directory-instead-of-binary':
        old = env.runtime / 'bin/python'; old.rename(env.root / 'saved-python'); old.mkdir()
    elif change == 'file-instead-of-source-parent':
        old = env.bundle / 'src/security'; old.rename(env.root / 'saved-security'); old.write_bytes(b'not dir')
    elif change == 'runtime-ancestor-alias':
        old = env.old / 'runtime'; old.rename(env.root / 'saved-runtime'); old.symlink_to(env.root / 'saved-runtime')
    elif change == 'candidate-parent-writable': env.dest.parent.chmod(0o775)
    elif change == 'bundle-fifo':
        old = env.bundle / 'src/ingestion.py'; old.rename(env.root / 'saved-ingestion'); os.mkfifo(old)
    elif change in {'helper-gid', 'target-gid'}:
        target = env.script if change == 'helper-gid' else env.runtime / 'bin/python'
        def altered(path):
            s = env.rootstat(path)
            if Path(path) == target: s.st_gid = 1000
            return s
        monkeypatch.setattr(helper, '_lstat', altered)
    elif change == 'sticky-dir': (env.runtime / 'bin').chmod(0o1755)
    elif change == 'setgid-file': (env.runtime / 'bin/python').chmod(0o2755)
    elif change == 'uppercase-pth':
        p = env.site / 'bad.PTH'; p.write_text('import disallowed'); p.chmod(0o644)
    elif change == 'lib64-nested-link': (env.runtime / 'bin/lib64').symlink_to('../lib')
    elif change == 'private-artifacts': (env.runtime / 'artifacts').mkdir(mode=0o755)
    elif change == 'bad-json-manifest': (env.bundle / 'audit_backend_payload.json').write_bytes(b'{}')
    with pytest.raises((helper.Rejected, OSError)):
        helper.stage_candidate()
    assert not os.path.lexists(env.dest)


@pytest.mark.parametrize('fault', ['initial-marker', 'clone-read', 'clone-write',
    'overlay-write', 'pending-write', 'final-rename', 'final-read'])
def test_failure_boundaries_preserve_no_false_complete(helper, env, monkeypatch, fault):
    before = positive_preflight(helper, env)
    old_read, old_write, old_open, old_rename = helper.read_protected, helper.write_new, helper.os.open, helper.os.rename
    def fail(message): raise OSError('independent injected '+message)
    if fault in {'initial-marker', 'clone-write', 'pending-write'}:
        relative = {'initial-marker': 'INCOMPLETE.json', 'clone-write': 'runtime/bin/python', 'pending-write': 'COMPLETE.pending'}[fault]
        def broken_write(path, data, mode):
            if path == env.dest / relative: fail(fault)
            return old_write(path, data, mode)
        monkeypatch.setattr(helper, 'write_new', broken_write)
    elif fault in {'clone-read', 'final-read'}:
        seen = 0
        def broken_read(path):
            nonlocal seen
            if path == env.runtime / 'bin/python':
                seen += 1
                if fault == 'clone-read' and seen > 1: fail(fault)
            if fault == 'final-read' and path == env.dest / 'COMPLETE.json': fail(fault)
            return old_read(path)
        monkeypatch.setattr(helper, 'read_protected', broken_read)
    elif fault == 'overlay-write':
        def broken_open(path, flags, *a, **k):
            if Path(path) == env.dest / 'runtime' / helper.SITE / 'src/ingestion.py' and flags & os.O_TRUNC: fail(fault)
            return old_open(path, flags, *a, **k)
        monkeypatch.setattr(helper.os, 'open', broken_open)
    elif fault == 'final-rename':
        def broken_rename(src, dest, *a, **k):
            if Path(dest) == env.dest / 'COMPLETE.json': fail(fault)
            return old_rename(src, dest, *a, **k)
        monkeypatch.setattr(helper.os, 'rename', broken_rename)
    with pytest.raises(OSError, match='independent injected'):
        helper.stage_candidate()
    assert env.dest.is_dir()
    assert not (env.dest / 'COMPLETE.json').exists()
    assert helper.inspect_runtime() == before
    if fault == 'final-read': assert (env.dest / 'COMPLETE.failed').is_file()
    if fault == 'final-rename': assert (env.dest / 'COMPLETE.pending').is_file()
    with pytest.raises(helper.Rejected, match='candidate exists'):
        helper.stage_candidate()


@pytest.mark.parametrize('name,expected', [
    ('ingestion.pyc', True), ('ingestion.pyo', True),
    ('__pycache__/ingestion.cpython-312.pyc', True),
    ('__pycache__/ingestion.cpython-312.opt-2.pyc', True),
    ('ingestion_other.pyc', False), ('__pycache__/ingestion_other.cpython-312.pyc', False),
    ('different/__pycache__/ingestion.cpython-312.pyc', False)])
def test_bytecode_exact_module_selection(helper, name, expected):
    assert helper.overlay_bytecode(helper.SITE / 'src' / name) is expected


def source_reader_script():
    block = re.findall(r'```bash\n(.*?)```', COMMANDS.read_text(), re.S)[0]
    # Extract only the unprivileged reader. Never execute the privileged block.
    return re.search(r'/usr/bin/python3 -I -S -B -c \'\n(import hashlib,os,sys.*?)\' "\$source"', block, re.S).group(1)


@pytest.mark.parametrize('change', ['same-bytes', 'bad-bytes', 'final-symlink', 'parent-alias', 'missing'])
def test_exact_unprivileged_bootstrap_reader(helper, tmp_path, change):
    reader = source_reader_script()
    good = b'controlled synthetic public payload\n'
    actual = tmp_path / 'real'
    actual.mkdir()
    payload = actual / 'payload'
    payload.write_bytes(good)
    target = payload
    if change == 'bad-bytes': payload.write_bytes(b'wrong payload')
    elif change == 'final-symlink':
        target = tmp_path / 'alias'; target.symlink_to(payload)
    elif change == 'parent-alias':
        alias = tmp_path / 'dir-alias'; alias.symlink_to(actual); target = alias / 'payload'
    elif change == 'missing': target = tmp_path / 'missing'
    cmd = ['/usr/bin/python3', '-I', '-S', '-B', '-c', reader, str(target), sha(good)]
    result = subprocess.run(cmd, capture_output=True, timeout=5)
    if change in {'same-bytes', 'parent-alias'}:
        assert result.returncode == 0 and result.stdout == good
        installed = tmp_path / 'ordinary-install-output'
        install = subprocess.run(['/usr/bin/install', '-m', '0600', '/dev/stdin', str(installed)],
            input=result.stdout, capture_output=True, timeout=5)
        assert install.returncode == 0 and installed.read_bytes() == good
        assert stat.S_IMODE(installed.stat().st_mode) == 0o600
    else:
        assert result.returncode != 0 and result.stdout == b''


def test_command_metadata_and_syntax(helper, tmp_path):
    document = COMMANDS.read_text()
    blocks = re.findall(r'```bash\n(.*?)```', document, re.S)
    assert len(blocks) == 2
    for i, block in enumerate(blocks):
        script = tmp_path / ('command-%d.sh' % i)
        script.write_text(block)
        result = subprocess.run(['/usr/bin/bash', '-n', str(script)], capture_output=True)
        assert result.returncode == 0, result.stderr.decode()
    entries = dict(re.findall(r'\["([^"]+)"\]="([0-9a-f]{64})"', blocks[0]))
    assert len(entries) == 10
    for name, expected in entries.items():
        path = REPO / name if name.startswith('src/') else SOURCE.parent / name
        assert sha(path.read_bytes()) == expected
    assert 'set -euo pipefail' in blocks[0]
    assert '/usr/bin/test "$(/usr/bin/id -u)" -ne 0' in blocks[0]
    assert '/dev/stdin "$bundle/$relative"' in blocks[0]
    assert str(helper.BUNDLE) in blocks[0]
    assert '-I -S -B' in blocks[1]
