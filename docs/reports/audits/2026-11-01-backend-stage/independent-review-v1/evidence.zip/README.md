# Independent review evidence

Scope is the seven paths in reviewed-manifest.json at candidate baseline
c14f595ccd53f432b455b16f116765d9aa6c9a14. Candidate source, Git index and tracked
files were not changed. Only reviewer scratch evidence was written.

## Execution

- run_existing.py ran the exact existing 58-case offline unit suite with cache
  writes disabled, and OS Python's fixed read-only --inspect-runtime command.
- run_challenges.py independent-01 ran 49 independently authored cases. Its full
  output and original harness are retained: 47 cases passed, two reviewer fixture
  errors occurred (not helper defects).
- The socket fixture originally exceeded AF_UNIX's pathname limit. The corrected
  case binds a relative pathname within its existing scratch runtime directory.
- The clone-read fault originally also broke the later preservation inspection.
  It now raises at precisely the same clone read once, leaving the preservation
  assertion intact. Both original failures and the harness diff are retained.
- run_challenges.py independent-02 -k 'socket or clone-read or fresh_execution'
  passed the two corrected cases plus 11 newly added trust challenges. The 47
  unaffected original cases were not rerun or double counted.
- case-reconciliation.json derives 60 distinct passing independent case identities
  from full JUnit, alongside the 58 existing cases. No skipped cases or observed
  test warnings. The preserved first harness invocation exited 1; the correction
  replay and existing suite exited 0.

Fresh full-suite reproduction (writes only a NEW reviewer scratch directory):

    /usr/bin/python3 -B run_challenges.py fresh-replay

The harness's fixed REPO path must refer to the exact reviewed checkout. Do not
replace its helper with a prior historical source. SHA256 bindings are present
in every subprocess receipt. A relocated reproduction must explicitly rebind
only REPO/output paths, preserve the source snapshot/hash, and record that change.

All ownership/root-launch metadata in challenge fixtures is synthetic. Inodes,
modes, links, byte writes, FIFOs, Unix socket path objects and clones use real
small filesystem trees confined to reviewer scratch. No actual root invocation,
bootstrap, application process, service, model, API, credentials, profile read,
protected write, activation or promotion occurred. The socket challenge binds a
local filesystem socket only; it neither listens nor exchanges messages.

Bootstrap review used full source inspection, AST parsing, Bash -n on both exact
blocks, and execution of ONLY the extracted ordinary-user hash-before-emission
reader on invented public scratch bytes. GNU install's /dev/stdin transport was
exercised only as UID 1000 into a new scratch file, with mode/hash readback. The
privileged preparation block and --stage entry point were NOT executed on host
protected paths. stage_candidate was invoked only against rebound scratch trees
and synthetic trust metadata in the offline fixtures.

## Archive layout

- candidate-snapshots/: exact seven reviewed files, retaining repository paths.
- dependency-snapshots/: eight bound c14 payload files plus pytest configuration.
  These are provenance dependencies, not an expanded source acceptance scope.
- independent-01/ and independent-02/: full stdout/stderr, JUnit, command/exit/hash
  receipts and the exact harness version used by that invocation.
- existing-suite.* and inspect-runtime.*: full original replay/inspection receipts.
- case-reconciliation.json: case IDs and old-to-corrected same-ID mapping.
- fixture-topology.json: object kinds, modes, regular-file hashes and link targets
  for retained scratch fixtures. Generated fixture bytes/special objects are NOT
  embedded as extractable archive members; the retained harness recreates them.
- archive-members.json: every other member's byte count, SHA256 and CRC32.

Archive CRC integrity and every payload SHA256 are verified after archive creation.
The adjacent archive receipt binds the complete ZIP SHA256 and CRC32. No private
instruction originals, protected runtime bytes, environment values or credentials
are archived. Future root staging/full-runtime boot/service activation/ledger,
cutover accounting and backup recovery remain separate owner-gated work.
