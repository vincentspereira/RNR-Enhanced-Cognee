import hashlib,json,os,pathlib,subprocess,concurrent.futures
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/backend-stage-worktree-20261101')
PY='/home/vincentspereira/agent-workspace/enhanced-cognee-deployment-20261020/.venv-deployment/bin/python'
commands={
'existing-suite':[PY,'-B','-m','pytest','-p','no:cacheprovider','--confcutdir=tests/unit','tests/unit/test_backend_stage_audit.py','-q','--junitxml='+str(OUT/'existing-suite.xml')],
'inspect-runtime':['/usr/bin/python3','-I','-S','-B',str(ROOT/'integrations/hermes/deployment/stage_audit_backend.py'),'--inspect-runtime'],
}
def run(item):
 label,cmd=item
 result=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=180)
 (OUT/(label+'.stdout')).write_text(result.stdout)
 (OUT/(label+'.stderr')).write_text(result.stderr)
 receipt={'command':cmd,'cwd':str(ROOT),'uid':os.geteuid(),'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 (OUT/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for receipt in pool.map(run,commands.items()): print(json.dumps(receipt))
manifest=json.loads((ROOT/'integrations/hermes/deployment/audit_backend_payload.json').read_bytes())
rows=[]
for row in manifest['files']:
 current=(ROOT/row['path']).read_bytes()
 baseline=subprocess.check_output(['git','show',manifest['source_commit']+':'+row['path']],cwd=ROOT)
 assert current==baseline
 assert hashlib.sha256(current).hexdigest()==row['new_sha256']
 rows.append({'path':row['path'],'baseline_match':True,'sha256':hashlib.sha256(current).hexdigest()})
(OUT/'payload-provenance.json').write_text(json.dumps(rows,indent=2)+'\n')
