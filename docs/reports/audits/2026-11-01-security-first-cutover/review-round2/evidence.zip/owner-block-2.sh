sudo /usr/bin/python3 -I -S -B \
  /opt/enhanced-cognee-memory/security-first-helper/prepare_security_first_cutover.py \
  --plan
